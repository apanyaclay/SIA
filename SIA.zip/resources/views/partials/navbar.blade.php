<!-- navbar-->
<div class="atas" >
    <nav  class="navbar fixed-top" style="background-color:#748E63;" >
      <div class="container-fluid px-5">
        <a style="font-family: Verdana, Geneva, Tahoma, sans-serif; font-weight: bolder; color: white;" class="navbar-brand" href="">
          <img class="logo1" src="{{ asset('assets/img/logo.png') }}"    srcset="">
        SISTEM INFORMASI AKADEMIK
        </a> 
        <form class="d-flex">
          <!-- <input style="width: 400px; ;" class="form-control me-2" type="search" placeholder="Search an Airport" aria-label="Search"> -->
          {{-- <a href="/login" style="background-color: #f8af7b; font-weight: bolder;" class="btn btn-outline-success mx-3">M A S U K</a> --}}

          @include('sweetalert::alert')
        </form>
      </div>
    </nav>
  </div> 