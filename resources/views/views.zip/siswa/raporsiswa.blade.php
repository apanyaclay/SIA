@extends('layouts.main_siswa')


@section('container')
<!-- Page Heading -->
<div class="isi ">

 <h1 class="jadwal h3 mb-0 text-gray-800" style="font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif; text-align: center;"> Hasil Belajar</h1></div>
 
 <!-- Isi Rapor Siswa -->

 <!-- SIKAP -->
 <div class="judulrapor px-3 py-3">    
 <div class="poin"> A. SIKAP</div>
 <div class="poin">1. Sikap Spiritual</div>
    </div>
 <table class="table text-center table-bordered">
    <thead class="table-secondary">
      <tr>
        <th scope="col">Predikat</th>
        <th scope="col">Deskripsi</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <th>B</th>
        <td style="text-align: justify;">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more.</td>
      </tr>
    </tbody>
  </table>
</table>

<div class="judulrapor px-3 py-3">    
    <div class="poin">2. Sikap Sosial</div>
       </div>
    <table class="table text-center table-bordered">
       <thead>
         <tr>
           <th scope="col">Predikat</th>
           <th scope="col">Deskripsi</th>
         </tr>
       </thead>
       <tbody>
         <tr>
           <th>B</th>
           <td style="text-align: justify;">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more.</td>
         </tr>
       </tbody>
     </table>
   </table>


   <!-- PENGETAHUAN -->
   <div class="judulrapor px-3 py-3">    
    <div class="poin"> B. PENGETAHUAN</div>
       </div>
    <table class="table text-center table-bordered">
       <thead class="table-secondary">
         <tr>
           <th scope="col">NO</th>
           <th scope="col">Mata Pelajaran </th>
           <th scope="col">Nilai</th>
           <th scope="col">Predikat</th>
           <th scope="col">Deskripsi</th>
         </tr>
       </thead>
       <tbody>
         <tr>
           <th>1</th>
           <td>Seni Budaya dan keterampilan</td>
           <th scope="row">1</th>
           <th scope="row">1</th>
           <td style="text-align: justify;">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more.</td>
         </tr>
         <tr>
            <th>1</th>
            <td>B</td>
            <th scope="row">1</th>
            <th scope="row">1</th>
            <td style="text-align: justify;">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more.</td>
          </tr>
          <tr>
            <th>1</th>
            <td>B</td>
            <th scope="row">1</th>
            <th scope="row">1</th>
            <td style="text-align: justify;">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more.</td>
          </tr>
          <tr>
            <th>1</th>
            <td>B</td>
            <th scope="row">1</th>
            <th scope="row">1</th>
            <td style="text-align: justify;">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more.</td>
          </tr>
          <tr>
            <th>1</th>
            <td>B</td>
            <th scope="row">1</th>
            <th scope="row">1</th>
            <td style="text-align: justify;">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more.</td>
          </tr>
          <tr>
            <th>1</th>
            <td>B</td>
            <th scope="row">1</th>
            <th scope="row">1</th>
            <td style="text-align: justify;">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more.</td>
          </tr>
          <tr>
            <th>1</th>
            <td>B</td>
            <th scope="row">1</th>
            <th scope="row">1</th>
            <td style="text-align: justify;">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more.</td>
          </tr>
          <tr>
            <th>1</th>
            <td>B</td>
            <th scope="row">1</th>
            <th scope="row">1</th>
            <td style="text-align: justify;">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more.</td>
          </tr>
          <tr>
            <th>1</th>
            <td>B</td>
            <th scope="row">1</th>
            <th scope="row">1</th>
            <td style="text-align: justify;">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more.</td>
          </tr>

       </tbody>
     </table>
   </table>

    <!-- KETERAMPILAN -->
    <div class="judulrapor px-3 py-3">    
        <div class="poin"> C. KETERAMPILAN</div>
           </div>
        <table class="table text-center table-bordered">
           <thead class="table-secondary">
             <tr>
               <th scope="col">NO</th>
               <th scope="col">Mata Pelajaran </th>
               <th scope="col">Nilai</th>
               <th scope="col">Predikat</th>
               <th scope="col">Deskripsi</th>
             </tr>
           </thead>
           <tbody>
             <tr>
               <th>1</th>
               <td>Seni Budaya dan keterampilan</td>
               <th scope="row">1</th>
               <th scope="row">1</th>
               <td style="text-align: justify;">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more.</td>
             </tr>
             <tr>
                <th>1</th>
                <td>B</td>
                <th scope="row">1</th>
                <th scope="row">1</th>
                <td style="text-align: justify;">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more.</td>
              </tr>
              <tr>
                <th>1</th>
                <td>B</td>
                <th scope="row">1</th>
                <th scope="row">1</th>
                <td style="text-align: justify;">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more.</td>
              </tr>
              <tr>
                <th>1</th>
                <td>B</td>
                <th scope="row">1</th>
                <th scope="row">1</th>
                <td style="text-align: justify;">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more.</td>
              </tr>
              <tr>
                <th>1</th>
                <td>B</td>
                <th scope="row">1</th>
                <th scope="row">1</th>
                <td style="text-align: justify;">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more.</td>
              </tr>
              <tr>
                <th>1</th>
                <td>B</td>
                <th scope="row">1</th>
                <th scope="row">1</th>
                <td style="text-align: justify;">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more.</td>
              </tr>
              <tr>
                <th>1</th>
                <td>B</td>
                <th scope="row">1</th>
                <th scope="row">1</th>
                <td style="text-align: justify;">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more.</td>
              </tr>
              <tr>
                <th>1</th>
                <td>B</td>
                <th scope="row">1</th>
                <th scope="row">1</th>
                <td style="text-align: justify;">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more.</td>
              </tr>
              <tr>
                <th>1</th>
                <td>B</td>
                <th scope="row">1</th>
                <th scope="row">1</th>
                <td style="text-align: justify;">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more.</td>
              </tr>
    
           </tbody>
         </table>
       </table>

       <!--EKSTRAKURIKULER -->
 <div class="judulrapor px-3 py-3">    
    <div class="poin">D . EKSTRAKURIKULER</div>
       </div>
       <table class="table text-center table-bordered">
        <thead class="table-secondary">
          <tr>
            <th scope="col">NO</th>
            <th scope="col">Kegiatan Ekstrakurikuler</th>
            <th scope="col">Nilai</th>
            <th scope="col">Keterangan</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <th>1</th>
            <td>Pramuka</td>
            <th scope="row">1</th>
            <td>keterangan apa saja yang bisa dimasukkan</td>
          </tr>
          <tr>
             <th>1</th>
             <td>B</td>
             <th scope="row">1</th>
             <th >1</th>
           </tr>
           <tr>
             <th>1</th>
             <td>B</td>
             <th scope="row">1</th>
             <th >1</th>
           </tr>  
        </tbody>
      </table>


             <!--PRESTASI -->
 <div class="judulrapor px-3 py-3">    
  <div class="poin">E. PRESTASI</div>
   </div>
   <table class="table text-center table-bordered">
    <thead class="table-secondary">
      <tr>
        <th scope="col">NO</th>
        <th scope="col">Jenis Prestasi</th>
        <th scope="col">Keterangan</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <th>1</th>
        <td>Juara 1 Memanah</td>
        <td>keterangan apa saja yang bisa dimasukkan</td>
      </tr>
      <tr>
         <th>2</th>
         <td>Juara 1 Memanah</td>
         <td>keterangan apa saja yang bisa dimasukkan</td>
       </tr>
       <tr>
         <th>3</th>
         <td>Juara 1 Memanah</td>
         <td>keterangan apa saja yang bisa dimasukkan</td>
       </tr>  
    </tbody>
  </table>
   

<!-- <button type="button" class="btn btn-secondary mt-3 mb-3" ><i
  class="fas fa-download fa-sm text-white-50"></i> Print Rapor </button> -->
</div>
@endsection